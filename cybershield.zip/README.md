# CyberShield AI (local demo)

A self-contained security-operations demo: detection rules, incident correlation, explainable risk scores, an evidence-linked rule-based assistant, simulated human-approved responses, an audit trail and report export. Plain HTML, CSS and JavaScript. No installs, no network requests, works offline.

**It is not a SIEM.** All events, endpoints and indicators are synthetic (DEMO DATA). The "assistant" is local JavaScript rules, not a live AI. Responses are simulations and never execute anything.

## Run it
1. In VS Code: File > Open Folder > `cybershield-ai`.
2. Open `index.html` in the file explorer, right-click > Reveal in File Explorer, then double-click it to open in your browser.

## Demo (5 minutes)
1. Overview: point out the DEMO DATA label and metrics.
2. Incident investigation > INC-001 (score 95): show the score breakdown, facts with event IDs, unconfirmed explanations and missing evidence.
3. Click Acknowledge, then Investigate. Add a note.
4. Response center: review "Recommend endpoint isolation", approve; reject another. Note "Simulated".
5. Settings: change "Failed logins to trigger" to 7 and watch the alert disappear. Generate a sample incident.
6. Reports: export Markdown and JSON. Audit history: show every step recorded.
7. Settings > Run tests.

## Architecture
```mermaid
flowchart LR
 F[Fixtures / import] --> D[Detection rules] --> C[Correlation] --> S[Risk score]
 S --> A[Rule-based assistant] --> UI[Dashboard]
 UI --> R[Simulated response] --> L[Audit log]
 UI --> X[Report export]
 L --> LS[(localStorage)]
```
`app.js` sections: data, state, detection, correlation and scoring, assistant, reports, tests, UI. Core logic has no DOM dependency.

## Risk score (0-100)
Severity (max 50) + correlated events (max 20) + repeated behavior (10) + endpoint importance (10) + evidence completeness (10). A transparent heuristic, not a probability. Confidence and business impact are shown separately.

## Limits
- Browser storage is editable and not tamper-proof; if blocked, changes are lost on close.
- MITRE mapping is a small demonstration set; see the source note in the app.
- Integration stubs (`CS.integrations`) are disabled. Never put API keys in browser code; use a server-side proxy.
- Not yet built: time-range filter, separate `docs/` files, dedicated judge Q&A and pitch text.

## Judge answers (short)
- *What is new?* Not the AI. The combination of evidence-cited explanations, visible scoring, approved-only simulated responses and an audit trail, in a zero-install demo.
- *How would you evaluate it?* Compare analyst triage time and accuracy with and without the explanations on labelled scenarios.

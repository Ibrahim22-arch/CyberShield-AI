'use strict';
(() => {
const M = 6e4, BASE = Date.parse('2026-10-20T08:00:00Z'), SEVS = ['low', 'medium', 'high', 'critical'];
const CS = { persist: true, KEY: 'cybershield-demo-v1' };
const fmt = t => new Date(t).toISOString().slice(5, 16).replace('T', ' ') + 'Z';
const pad = (n, w) => String(n).padStart(w, '0');

/* ---------- Data: simulated endpoints, rules, MITRE demo mapping, indicators ---------- */
CS.endpoints = [
  { id: 'EP-01', host: 'WS-FIN-01', os: 'Windows 11', imp: 2, seen: '2026-10-20 08:40Z', status: 'Simulated' },
  { id: 'EP-02', host: 'SRV-DB-01', os: 'Windows Server 2022', imp: 3, seen: '2026-10-20 10:15Z', status: 'Simulated' },
  { id: 'EP-03', host: 'WS-HR-02', os: 'Windows 10', imp: 2, seen: '2026-10-20 11:30Z', status: 'Simulated' },
  { id: 'EP-04', host: 'LAP-DEV-03', os: 'Ubuntu 24.04', imp: 1, seen: '2026-10-20 13:02Z', status: 'Simulated' },
  { id: 'EP-05', host: 'SRV-WEB-01', os: 'Ubuntu 24.04', imp: 3, seen: '2026-10-20 13:00Z', status: 'Simulated' }];
CS.rules = {
  'R-AUTH-001': { name: 'Repeated failed logins', sev: 'high' },
  'R-AUTH-002': { name: 'Successful login after repeated failures', sev: 'critical' },
  'R-FILE-001': { name: 'Burst of file modifications', sev: 'medium' },
  'R-ADMIN-001': { name: 'Unusual administrative change', sev: 'high' },
  'R-PROC-001': { name: 'Flagged synthetic process record', sev: 'medium' } };
CS.mitre = {
  'R-AUTH-001': { tactic: 'Credential Access', tech: 'T1110 Brute Force', why: 'Many failed logins for one account in a short window fit the pattern, but do not prove intent.' },
  'R-AUTH-002': { tactic: 'Initial Access', tech: 'T1078 Valid Accounts', why: 'A success after repeated failures is consistent with use of a valid account. A legitimate user who mistyped is also possible.' },
  'R-ADMIN-001': { tactic: 'Persistence', tech: 'T1098 Account Manipulation', why: 'A group membership change by a service account fits this technique, if the change was unauthorized.' },
  'R-FILE-001': { tactic: null, tech: null, why: 'Not mapped. File modifications alone do not identify a technique.' },
  'R-PROC-001': { tactic: null, tech: null, why: 'Not mapped. The synthetic record lacks the detail needed to support a technique.' } };
CS.mitreSource = 'Demonstration mapping written by the project author. Verify against attack.mitre.org. Not comprehensive.';
CS.intel = [
  { ind: '192.0.2.44', type: 'IP (RFC 5737 documentation range)', risk: 'Suspicious (demo)', why: 'Source of repeated failed logins in the demo data.' },
  { ind: '198.51.100.23', type: 'IP (RFC 5737 documentation range)', risk: 'Suspicious (demo)', why: 'Source of an administrative change in the demo data.' },
  { ind: '203.0.113.9', type: 'IP (RFC 5737 documentation range)', risk: 'Suspicious (demo)', why: 'Used by the sample incident generator.' },
  { ind: 'login.corp-portal.example', type: 'Domain (reserved example TLD)', risk: 'Unknown (demo)', why: 'Fictitious indicator. Not seen in any event.' }];
CS.integrations = { ai: { enabled: false, note: 'Future: call a server-side proxy. Never put API keys in browser code.', analyze: async () => { throw new Error('AI integration not configured'); } },
  intel: { enabled: false, note: 'Future: authorized threat-intelligence APIs via a backend.', lookup: async () => { throw new Error('Threat-intel integration not configured'); } } };
CS.actions = {
  investigate: { label: 'Mark for investigation', impact: 'Sets the incident status to investigating. Internal record only.' },
  isolate: { label: 'Recommend endpoint isolation', impact: 'Creates a recommendation record. No device is isolated.' },
  escalate: { label: 'Generate escalation record', impact: 'Creates a record for a human owner. No message is sent.' },
  report: { label: 'Create incident report', impact: 'Downloads a local report file.' },
  complete: { label: 'Mark simulated response completed', impact: 'Records completion of a simulation. Nothing was blocked or changed.' } };

/* ---------- State ---------- */
CS.fixtures = () => {
  let n = 0;
  const E = (m, ep, cat, user, src, desc, evidence = {}, sev = 'low') => ({ id: 'EV-' + pad(++n, 4), ts: BASE + m * M, endpoint: ep, category: cat, user, src, ruleId: null, severity: sev, desc, evidence, source: 'DEMO' });
  const ev = [];
  [5, 6, 7, 7.5, 8, 9].forEach(m => ev.push(E(m, 'WS-FIN-01', 'auth_fail', 'jdoe', '192.0.2.44', 'Failed login (synthetic)', { reason: 'bad password' })));
  ev.push(E(11, 'WS-FIN-01', 'auth_ok', 'jdoe', '192.0.2.44', 'Successful login (synthetic)', { method: 'password' }));
  ev.push(E(20, 'WS-FIN-01', 'file_modify', 'jdoe', null, 'File modified (synthetic)', { path: 'Q3_payroll.xlsx' }));
  ev.push(E(25, 'WS-FIN-01', 'process', 'jdoe', null, 'Synthetic record: office app started a script host', { flag: 'synthetic-suspicious' }, 'medium'));
  [120, 122, 124].forEach(m => ev.push(E(m, 'SRV-DB-01', 'file_modify', null, null, 'Backup file modified (synthetic)', { path: '/db/backup/nightly.bak' })));
  ev.push(E(130, 'SRV-DB-01', 'admin_change', 'svc_backup', '198.51.100.23', 'Account added to Administrators group (synthetic)', { group: 'Administrators' }, 'medium'));
  ev.push(E(200, 'WS-HR-02', 'process', 'asmith', null, 'Synthetic record: unsigned helper started', { flag: 'synthetic-suspicious' }, 'medium'));
  ev.push(E(205, 'WS-HR-02', 'process', 'asmith', null, 'Synthetic record: routine updater started', { flag: 'none' }));
  [300, 301].forEach(m => ev.push(E(m, 'LAP-DEV-03', 'auth_fail', 'devuser', '192.0.2.77', 'Failed login (synthetic)', { reason: 'bad password' })));
  return ev;
};
CS.fresh = () => ({ events: CS.fixtures(), inc: {}, next: 1, audit: [], gen: 0, cfg: { failN: 5, failWin: 10, corrWin: 60 } });
CS.state = CS.fresh();
CS.save = () => { if (!CS.persist) return; try { const s = CS.state; localStorage.setItem(CS.KEY, JSON.stringify({ events: s.events, inc: s.inc, next: s.next, audit: s.audit, gen: s.gen, cfg: s.cfg })); } catch (e) { CS.saveFailed = true; } };
CS.load = () => { try { const r = JSON.parse(localStorage.getItem(CS.KEY)); if (!r) return false; const v = CS.validateEvents(r.events); if (!v.ok || typeof r.inc !== 'object' || !Array.isArray(r.audit)) return false; Object.assign(CS.state, { events: v.events, inc: r.inc || {}, next: +r.next || 1, audit: r.audit, gen: +r.gen || 0 }); Object.assign(CS.state.cfg, r.cfg || {}); return true; } catch (e) { return false; } };
CS.log = (action, inc, outcome) => { const a = CS.state.audit; a.push({ id: 'AUD-' + pad(a.length + 1, 4), ts: new Date().toISOString(), action, inc: inc || null, outcome, mode: 'DEMO (simulated)' }); };
CS.validateEvents = arr => {
  if (!Array.isArray(arr)) return { ok: false, errors: ['Expected an array of events'], events: [] };
  const out = [], errors = [], str = (v, l) => (typeof v === 'string' ? v.slice(0, l) : null);
  arr.forEach((e, i) => {
    if (!e || typeof e !== 'object' || !str(e.id, 20) || !Number.isFinite(e.ts) || !str(e.endpoint, 40) || !str(e.category, 30)) { errors.push('Event ' + i + ' is missing id, ts, endpoint or category'); return; }
    out.push({ id: str(e.id, 20), ts: e.ts, endpoint: str(e.endpoint, 40), category: str(e.category, 30), user: str(e.user, 60), src: str(e.src, 60), ruleId: null, severity: SEVS.includes(e.severity) ? e.severity : 'low', desc: str(e.desc, 200) || '', evidence: e.evidence && typeof e.evidence === 'object' && !Array.isArray(e.evidence) ? JSON.parse(JSON.stringify(e.evidence)) : {}, source: 'IMPORTED' });
  });
  return { ok: !errors.length && out.length > 0, errors: out.length ? errors : errors.concat('No valid events'), events: out };
};

/* ---------- Detection ---------- */
CS.detect = (events, cfg) => {
  const R = CS.rules, al = [], s = [...events].sort((a, b) => a.ts - b.ts);
  events.forEach(e => e.ruleId = null);
  const mk = (rid, evs) => { evs.forEach(e => e.ruleId = e.ruleId || rid); al.push({ ruleId: rid, severity: R[rid].sev, endpoint: evs[0].endpoint, eventIds: evs.map(e => e.id), ts: evs[0].ts, last: evs[evs.length - 1].ts, title: R[rid].name }); };
  const grp = {};
  s.filter(e => e.category === 'auth_fail').forEach(e => (grp[e.endpoint + '|' + e.user] = grp[e.endpoint + '|' + e.user] || []).push(e));
  Object.values(grp).forEach(g => {
    for (let i = 0; i + cfg.failN <= g.length; i++) if (g[i + cfg.failN - 1].ts - g[i].ts <= cfg.failWin * M) {
      const w = g.filter(e => e.ts >= g[i].ts && e.ts <= g[i].ts + cfg.failWin * M); mk('R-AUTH-001', w);
      const ok = s.find(e => e.category === 'auth_ok' && e.endpoint === g[0].endpoint && e.user === g[0].user && e.ts > w[w.length - 1].ts && e.ts - w[w.length - 1].ts <= 15 * M);
      if (ok) mk('R-AUTH-002', [ok]); break; }
  });
  const fm = {}; s.filter(e => e.category === 'file_modify').forEach(e => (fm[e.endpoint] = fm[e.endpoint] || []).push(e));
  Object.values(fm).forEach(g => { for (let i = 0; i + 3 <= g.length; i++) if (g[i + 2].ts - g[i].ts <= 10 * M) { mk('R-FILE-001', g.filter(e => e.ts >= g[i].ts && e.ts <= g[i].ts + 10 * M)); break; } });
  s.filter(e => e.category === 'admin_change').forEach(e => mk('R-ADMIN-001', [e]));
  s.filter(e => e.category === 'process' && e.evidence && e.evidence.flag === 'synthetic-suspicious').forEach(e => mk('R-PROC-001', [e]));
  al.sort((a, b) => a.ts - b.ts || a.ruleId.localeCompare(b.ruleId)); al.forEach((a, i) => a.id = 'AL-' + pad(i + 1, 3));
  return al;
};

/* ---------- Correlation + risk score ---------- */
CS.score = (inc, s) => {
  const evs = inc.eventIds.map(id => s.events.find(e => e.id === id)).filter(Boolean), ep = CS.endpoints.find(e => e.host === inc.endpoint), imp = ep ? ep.imp : 1;
  const sevP = { low: 10, medium: 25, high: 40, critical: 50 }[inc.severity], cnt = Math.min(20, (evs.length - 1) * 4);
  const rep = inc.alerts.length > 1 || inc.alerts.some(a => a.ruleId === 'R-AUTH-001') ? 10 : 0, imP = { 1: 3, 2: 6, 3: 10 }[imp] ?? 3;
  const frac = evs.length ? evs.filter(e => e.user && e.src).length / evs.length : 0, comp = Math.round(frac * 10);
  const parts = [{ name: 'Highest alert severity', pts: sevP, max: 50, why: inc.severity }, { name: 'Correlated events', pts: cnt, max: 20, why: evs.length + ' events, 4 points each beyond the first' },
    { name: 'Repeated behavior', pts: rep, max: 10, why: rep ? 'Multiple alerts or a repeated-failure rule' : 'Single isolated alert' }, { name: 'Endpoint importance (configured)', pts: imP, max: 10, why: 'Importance ' + imp + ' of 3 for ' + inc.endpoint },
    { name: 'Evidence completeness', pts: comp, max: 10, why: Math.round(frac * 100) + '% of events have both user and source address' }];
  return { total: Math.min(100, parts.reduce((a, p) => a + p.pts, 0)), parts, confidence: frac >= .8 ? 'higher' : frac >= .5 ? 'moderate' : 'lower', impact: ['', 'low', 'medium', 'high'][imp] };
};
CS.recompute = () => {
  const s = CS.state; s.alerts = CS.detect(s.events, s.cfg); const by = {}, out = [];
  s.alerts.forEach(a => (by[a.endpoint] = by[a.endpoint] || []).push(a));
  Object.entries(by).forEach(([ep, list]) => { let g = null; list.forEach(a => { if (g && a.ts - g.last <= s.cfg.corrWin * M) { g.alerts.push(a); g.last = Math.max(g.last, a.last); } else { g = { endpoint: ep, alerts: [a], last: a.last }; out.push(g); } }); });
  out.forEach(g => {
    g.eventIds = [...new Set(g.alerts.flatMap(a => a.eventIds))].sort(); g.first = Math.min(...g.alerts.map(a => a.ts)); g.key = g.endpoint + '@' + g.eventIds[0];
    if (!s.inc[g.key]) { s.inc[g.key] = { id: 'INC-' + pad(s.next++, 3), status: 'new', notes: [], responses: [] }; CS.log('Incident created', s.inc[g.key].id, 'Created by correlation rule (same endpoint, ' + s.cfg.corrWin + ' min window)'); }
    const st = g.st = s.inc[g.key]; g.id = st.id; g.status = st.status;
    g.severity = g.alerts.reduce((m, a) => SEVS.indexOf(a.severity) > SEVS.indexOf(m) ? a.severity : m, 'low');
    g.title = g.endpoint + ': ' + [...new Set(g.alerts.map(a => a.title))].join(' + ');
    g.explanation = g.alerts.length + ' alert(s) grouped because they share endpoint ' + g.endpoint + ' and each starts within ' + s.cfg.corrWin + ' min of the previous one.';
    g.score = CS.score(g, s);
  });
  s.incidents = out.sort((a, b) => a.id.localeCompare(b.id));
};
CS.inc = id => CS.state.incidents.find(i => i.id === id);
const FLOW = { acknowledge: [['new'], 'acknowledged'], investigate: [['new', 'acknowledged'], 'investigating'], resolve: [['new', 'acknowledged', 'investigating'], 'resolved'], reopen: [['resolved'], 'investigating'] };
CS.setStatus = (id, act) => { const i = CS.inc(id), f = FLOW[act]; if (!i || !f || !f[0].includes(i.st.status)) return false; i.st.status = f[1]; CS.log('Incident ' + ({acknowledge:'acknowledged',investigate:'set to investigating',resolve:'resolved',reopen:'reopened'})[act], id, 'Status now ' + f[1]); CS.recompute(); CS.save(); return true; };
CS.addNote = (id, t) => { const i = CS.inc(id); t = String(t || '').trim().slice(0, 500); if (!i || !t) return false; i.st.notes.push({ ts: new Date().toISOString(), text: t }); CS.log('Investigation note added', id, 'Note stored locally'); CS.save(); return true; };
CS.respond = (id, key, approved) => {
  const i = CS.inc(id), a = CS.actions[key]; if (!i || !a) return null;
  const r = { action: a.label, decision: approved ? 'approved' : 'rejected', simulated: true, ts: new Date().toISOString() }; i.st.responses.push(r);
  CS.log(approved ? 'Response approved' : 'Response rejected', id, a.label + ' (SIMULATED, nothing executed)');
  if (approved && key === 'investigate') CS.setStatus(id, 'investigate'); CS.save(); return r;
};
CS.gen = kind => {
  const s = CS.state, eps = ['SRV-WEB-01', 'LAP-DEV-03', 'WS-HR-02'], ep = eps[s.gen % 3], t0 = 400 + s.gen * 90, mx = Math.max(0, ...s.events.map(e => +e.id.slice(3) || 0));
  let n = mx; const E = (m, cat, user, src, desc, evd = {}) => s.events.push({ id: 'EV-' + pad(++n, 4), ts: BASE + (t0 + m) * M, endpoint: ep, category: cat, user, src, ruleId: null, severity: 'low', desc, evidence: evd, source: 'DEMO' });
  if (kind === 'incident') { [0, 1, 2, 3, 4, 5].forEach(m => E(m, 'auth_fail', 'opsuser', '203.0.113.9', 'Failed login (synthetic)', { reason: 'bad password' })); s.gen++; }
  else { const last = s.events.filter(e => e.source === 'DEMO').slice(-1)[0]; E(8, 'auth_ok', 'opsuser', '203.0.113.9', 'Successful login (synthetic)', { method: 'password' }); E(12, 'admin_change', 'opsuser', '203.0.113.9', 'Account added to Administrators group (synthetic)', { group: 'Administrators' }); s.gen++; }
  CS.log('Demo events generated', null, kind + ' on ' + ep); CS.recompute(); CS.save();
};

/* ---------- Investigation assistant (local rules, not a live AI) ---------- */
CS.explain = inc => {
  const s = CS.state, ev = id => s.events.find(e => e.id === id), facts = [], poss = [], miss = [];
  inc.alerts.forEach(a => {
    const es = a.eventIds.map(ev).filter(Boolean), f = es[0], l = es[es.length - 1];
    if (a.ruleId === 'R-AUTH-001') { facts.push({ t: es.length + ' failed logins for account "' + f.user + '" on ' + a.endpoint + ' between ' + fmt(f.ts) + ' and ' + fmt(l.ts), ids: a.eventIds }); poss.push('Password guessing against the account, or a user repeatedly mistyping. The events alone cannot tell which.'); }
    else if (a.ruleId === 'R-AUTH-002') { facts.push({ t: 'A successful login for "' + f.user + '" occurred at ' + fmt(f.ts) + ', after the failures', ids: a.eventIds }); poss.push('The account may have been accessed by someone who guessed the password. A legitimate user who then typed it correctly is equally consistent.'); }
    else if (a.ruleId === 'R-FILE-001') { facts.push({ t: es.length + ' file modification records on ' + a.endpoint + ' within 10 minutes', ids: a.eventIds }); poss.push('Could be scheduled backup activity or unwanted modification. No process information links them.'); }
    else if (a.ruleId === 'R-ADMIN-001') { facts.push({ t: 'Account "' + f.user + '" was recorded as added to a privileged group at ' + fmt(f.ts), ids: a.eventIds }); poss.push('Possible privilege change. It could be an authorized admin task; no change ticket is available to compare.'); }
    else if (a.ruleId === 'R-PROC-001') { facts.push({ t: 'A synthetic process record was flagged as suspicious at ' + fmt(f.ts), ids: a.eventIds }); poss.push('Flag is set in the demo fixture. No file hash or parent-process chain is available.'); }
  });
  const evs = inc.eventIds.map(ev).filter(Boolean);
  if (evs.some(e => !e.src)) miss.push('Source address is missing for: ' + evs.filter(e => !e.src).map(e => e.id).join(', '));
  if (evs.some(e => !e.user)) miss.push('Username is missing for: ' + evs.filter(e => !e.user).map(e => e.id).join(', '));
  miss.push('No network, email or real endpoint telemetry exists in this demo. Intent and success of any attack cannot be established.');
  return { summary: 'Local rules found ' + inc.alerts.length + ' alert(s) on ' + inc.endpoint + ' (' + inc.severity + ' severity, risk score ' + inc.score.total + '/100). These are observations from ' + (evs[0] ? evs[0].source : 'DEMO') + ' records, not confirmed compromise.',
    facts, poss, miss,
    steps: ['Confirm with the account owner whether the activity was theirs.', 'Compare the source addresses with known office or VPN ranges.', 'Review the full event timeline for activity just before and after.', 'Record findings as an investigation note.'],
    containment: ['Consider a password reset for the affected account (human decision).', 'Consider isolating the endpoint if the owner cannot confirm activity (human decision, simulated here).'] };
};

/* ---------- Reports ---------- */
CS.report = (inc, mode) => {
  const s = CS.state, x = CS.explain(inc), evs = inc.eventIds.map(id => s.events.find(e => e.id === id));
  const o = { generated: new Date().toISOString(), dataset: 'DEMO / synthetic. Not real observations.', id: inc.id, title: inc.title, severity: inc.severity, status: inc.status, first: new Date(inc.first).toISOString(), last: new Date(inc.last).toISOString(), endpoint: inc.endpoint,
    correlation: inc.explanation, risk: inc.score, findings: x, mitre: inc.alerts.map(a => ({ rule: a.ruleId, ...CS.mitre[a.ruleId], source: CS.mitreSource })), events: evs, notes: inc.st.notes, responses: inc.st.responses, uncertainties: x.miss };
  if (mode === 'json') return JSON.stringify(o, null, 2);
  const L = ['# Incident report ' + o.id + ': ' + o.title, '', '> DEMO DATA. All events are synthetic. Responses below were simulated; nothing was executed.', '', '- Severity: ' + o.severity, '- Status: ' + o.status, '- Observed: ' + fmt(inc.first) + ' to ' + fmt(inc.last), '- Endpoint: ' + o.endpoint, '- Correlation: ' + o.correlation, '',
    '## Risk score breakdown', 'Total ' + o.risk.total + '/100 (explainable heuristic, not a probability of compromise). Evidence confidence: ' + o.risk.confidence + '. Business impact: ' + o.risk.impact + '.', ...o.risk.parts.map(p => '- ' + p.name + ': ' + p.pts + '/' + p.max + ' (' + p.why + ')'), '',
    '## Summary', x.summary, '', '## Observed facts', ...x.facts.map(f => '- ' + f.t + ' [' + f.ids.join(', ') + ']'), '', '## Possible explanations (not confirmed)', ...x.poss.map(p => '- ' + p), '',
    '## MITRE ATT&CK (demonstration mapping)', ...o.mitre.map(m => '- ' + m.rule + ': ' + (m.tech ? m.tactic + ', ' + m.tech : 'no mapping') + '. ' + m.why), '', '## Timeline', ...evs.map(e => '- ' + fmt(e.ts) + ' ' + e.id + ' ' + e.category + ' ' + e.desc), '',
    '## Recommended actions', ...x.steps.map(t => '- ' + t), ...x.containment.map(t => '- ' + t), '', '## Response history', ...(o.responses.length ? o.responses.map(r => '- ' + r.ts + ' ' + r.action + ': ' + r.decision + ' (simulated)') : ['- None']), '', '## Remaining uncertainties', ...x.miss.map(m => '- ' + m), ''];
  return L.join('\n');
};

/* ---------- Tests (run in the browser on demand) ---------- */
CS.tests = [
  ['Repeated failed-login detection', () => { const s = CS.state; const a = s.alerts.find(a => a.ruleId === 'R-AUTH-001'); return a && a.endpoint === 'WS-FIN-01' && a.eventIds.length === 6 && !s.alerts.some(a => a.endpoint === 'LAP-DEV-03'); }],
  ['Correlation groups related events, no duplicates', () => { const n = CS.state.incidents.length; CS.recompute(); const f = CS.state.incidents.find(i => i.endpoint === 'WS-FIN-01'); return n === 3 && CS.state.incidents.length === 3 && f.alerts.length === 3; }],
  ['Risk score calculation (WS-FIN-01 = 95)', () => CS.state.incidents.find(i => i.endpoint === 'WS-FIN-01').score.total === 95],
  ['Incident state changes and invalid transition', () => { const id = 'INC-001'; return CS.setStatus(id, 'acknowledge') && CS.setStatus(id, 'investigate') && CS.setStatus(id, 'resolve') && !CS.setStatus(id, 'acknowledge') && CS.setStatus(id, 'reopen') && CS.inc(id).status === 'investigating'; }],
  ['Response approval and rejection', () => { const a = CS.respond('INC-002', 'isolate', true), b = CS.respond('INC-002', 'escalate', false); return a.decision === 'approved' && b.decision === 'rejected' && a.simulated && CS.inc('INC-002').st.responses.length === 2; }],
  ['Audit records generated', () => { const a = CS.state.audit; return a.length >= 8 && a.every(r => r.id && r.ts && r.mode) && a.some(r => r.action === 'Response rejected'); }],
  ['JSON report export', () => { const o = JSON.parse(CS.report(CS.inc('INC-001'), 'json')); return o.id === 'INC-001' && /DEMO/.test(o.dataset) && o.risk.total === 95; }],
  ['Markdown report export', () => { const m = CS.report(CS.inc('INC-001'), 'md'); return m.includes('## Risk score breakdown') && m.includes('DEMO DATA') && m.includes('## Remaining uncertainties'); }],
  ['Malformed import handled', () => [null, 'x', {}, [null, { id: 1 }], [], [{ id: 'EV-1', ts: 'x' }]].every(v => { try { return CS.validateEvents(v).ok === false; } catch (e) { return false; } }) && CS.validateEvents(CS.fixtures()).ok],
  ['Empty dataset handled', () => { CS.state.events = []; CS.recompute(); return CS.state.incidents.length === 0 && CS.state.alerts.length === 0; }]];
CS.runTests = () => { const keep = CS.state, kp = CS.persist; CS.persist = false; CS.state = CS.fresh(); CS.recompute();
  const res = CS.tests.map(([n, f]) => { let ok = false, err = ''; try { ok = !!f(); } catch (e) { err = String(e); } return { n, ok, err }; });
  CS.state = keep; CS.persist = kp; return res; };

/* ---------- UI ---------- */
if (typeof document === 'undefined') { globalThis.CS = CS; return; }
const h = (t, a = {}, ...c) => { const e = document.createElement(t); for (const [k, v] of Object.entries(a)) k === 'class' ? e.className = v : k.startsWith('on') ? e.addEventListener(k.slice(2), v) : e.setAttribute(k, v); c.flat().forEach(x => e.append(x && x.nodeType ? x : String(x == null ? '' : x))); return e; };
const pill = s => h('span', { class: 'pill ' + s }, s);
const F = { sev: '', ep: '', st: '', q: '' }; let sel = null, page = 'overview', preview = '';
const toast = m => { const t = h('div', {}, m); $('#toasts').append(t); setTimeout(() => t.remove(), 3500); };
const $ = s => document.querySelector(s);
const ask = (title, body, ok) => new Promise(r => { const d = $('#dlg'); $('#dt').textContent = title; $('#db').textContent = body; $('#dyes').textContent = ok || 'Confirm'; d.onclose = () => r(d.returnValue === 'y'); $('#dyes').onclick = () => d.close('y'); $('#dno').onclick = () => d.close('n'); d.showModal(); });
const download = (name, text, type) => { const a = h('a', { href: URL.createObjectURL(new Blob([text], { type })), download: name }); document.body.append(a); a.click(); a.remove(); };
const table = (cols, rows, onrow) => rows.length ? h('div', { class: 'tw' }, h('table', {}, h('thead', {}, h('tr', {}, cols.map(c => h('th', {}, c[0])))), h('tbody', {}, rows.map(r => { const tr = h('tr', onrow ? { tabindex: '0', onclick: () => onrow(r), onkeydown: e => { if (e.key === 'Enter') onrow(r); } } : {}, cols.map(c => h('td', {}, c[1](r)))); return tr; })))) : h('div', { class: 'empty' }, 'Nothing matches. Clear the filters or load the original sample dataset in Settings.');
const vis = () => { const s = CS.state, q = F.q.toLowerCase(), okEp = e => !F.ep || e === F.ep;
  return { alerts: s.alerts.filter(a => (!F.sev || a.severity === F.sev) && okEp(a.endpoint) && (!q || (a.title + a.eventIds.join()).toLowerCase().includes(q))), incs: s.incidents.filter(i => (!F.sev || i.severity === F.sev) && okEp(i.endpoint) && (!F.st || i.status === F.st) && (!q || (i.title + i.id).toLowerCase().includes(q))), events: s.events.filter(e => okEp(e.endpoint)) }; };
const sel1 = (label, key, opts) => h('label', {}, label + ' ', h('select', { onchange: e => { F[key] = e.target.value; render(); } }, h('option', { value: '' }, 'All'), opts.map(o => h('option', { value: o, ...(F[key] === o ? { selected: '' } : {}) }, o))));
const filters = () => h('div', { class: 'row' }, sel1('Severity', 'sev', SEVS), sel1('Endpoint', 'ep', CS.endpoints.map(e => e.host)), sel1('Status', 'st', ['new', 'acknowledged', 'investigating', 'resolved']), h('input', { type: 'search', placeholder: 'Search', 'aria-label': 'Search', value: F.q, oninput: e => { F.q = e.target.value; clearTimeout(filters.t); filters.t = setTimeout(() => { render(); const i = $('input[type=search]'); i && (i.focus(), i.setSelectionRange(99, 99)); }, 250); } }));
const incRow = [['ID', i => i.id], ['Title', i => i.title], ['Severity', i => pill(i.severity)], ['Risk', i => i.score.total + '/100'], ['Status', i => pill(i.status)], ['Last seen', i => fmt(i.last)]];
const openInc = i => { sel = i.id; go('incidents'); };
const dist = (items, key, cls) => h('div', {}, items.map(([n, v, mx]) => h('div', { class: 'bl ' + (cls ? n : '') }, h('span', {}, n), h('div', { style: 'color:inherit' }, h('div', { class: 'bar', style: 'width:' + (mx ? Math.max(3, v / mx * 100) : 0) + '%' })), h('span', {}, v))));

const PAGES = {
  overview() { const s = CS.state, v = vis(), cnt = x => v.alerts.filter(a => a.severity === x).length, eps = new Set(v.incs.map(i => i.endpoint)), rules = {};
    v.alerts.forEach(a => rules[a.ruleId] = (rules[a.ruleId] || 0) + 1);
    const lo = Math.min(...v.events.map(e => e.ts)), hi = Math.max(...v.events.map(e => e.ts)), B = 12, b = Array(B).fill(0); v.events.forEach(e => b[Math.min(B - 1, Math.floor((e.ts - lo) / ((hi - lo) || 1) * B))]++);
    const K = [['Total events', v.events.length], ['Critical alerts', cnt('critical')], ['High alerts', cnt('high')], ['Open incidents', v.incs.filter(i => i.status !== 'resolved').length], ['Resolved incidents', v.incs.filter(i => i.status === 'resolved').length], ['Affected endpoints', eps.size]];
    const mx = Math.max(1, ...SEVS.map(cnt));
    return h('div', {}, h('div', { class: 'warn' }, 'DEMO DATA: all events, endpoints and indicators are synthetic. Nothing here is live telemetry.'), filters(),
      h('div', { class: 'grid' }, K.map(([l, n]) => h('div', { class: 'card kpi' }, h('b', {}, n), h('span', {}, l)))),
      h('div', { class: 'grid g2' }, h('div', { class: 'card' }, h('h2', {}, 'Event trend (synthetic timeline)'), v.events.length ? h('div', { class: 'trend', role: 'img', 'aria-label': 'Events over time' }, b.map(n => h('i', { style: 'height:' + n / Math.max(...b) * 100 + '%', title: n + ' events' }))) : h('div', { class: 'empty' }, 'No events')),
        h('div', { class: 'card' }, h('h2', {}, 'Alert severity'), dist(SEVS.map(x => [x, cnt(x), mx]), 'sev', true)),
        h('div', { class: 'card' }, h('h2', {}, 'Most triggered rules'), table([['Rule', r => r[0] + ' ' + CS.rules[r[0]].name], ['Count', r => r[1]]], Object.entries(rules).sort((a, b) => b[1] - a[1]))),
        h('div', { class: 'card' }, h('h2', {}, 'Recent incidents'), table(incRow.slice(0, 5), v.incs.slice(-5).reverse(), openInc))));
  },
  alerts() { const v = vis(); return h('div', {}, filters(), table([['Alert', a => a.id], ['Rule', a => a.ruleId + ' ' + a.title], ['Severity', a => pill(a.severity)], ['Endpoint', a => a.endpoint], ['Time', a => fmt(a.ts)], ['Events', a => a.eventIds.join(', ')]], v.alerts, a => { const i = CS.state.incidents.find(i => i.alerts.includes(a)); i && openInc(i); })); },
  incidents() { const v = vis(), i = CS.inc(sel); if (!i) return h('div', {}, filters(), table(incRow, v.incs, openInc));
    const x = CS.explain(i), evs = i.eventIds.map(id => CS.state.events.find(e => e.id === id)), btn = (l, f, c) => h('button', { class: c || '', onclick: f }, l), st = a => () => { CS.setStatus(i.id, a) ? toast('Incident ' + i.id + ' now ' + CS.inc(i.id).status) : toast('Not allowed from status ' + i.status); render(); };
    const note = h('input', { 'aria-label': 'Investigation note', placeholder: 'Add investigation note', maxlength: '500' });
    return h('div', {}, btn('Back to list', () => { sel = null; render(); }), h('h2', { style: 'margin-top:12px' }, i.id + ': ' + i.title), h('div', { class: 'row' }, pill(i.severity), pill(i.status), h('span', { class: 'mu' }, fmt(i.first) + ' to ' + fmt(i.last) + ' | Related events: ' + i.eventIds.join(', '))),
      h('div', { class: 'row' }, ['acknowledge', 'investigate', 'resolve', 'reopen'].map(a => btn(a[0].toUpperCase() + a.slice(1), st(a))), btn('Respond (simulated)', () => { go('response'); }, 'pri')),
      h('div', { class: 'seg' }, h('div', { class: 'card' }, h('h3', {}, 'Risk score (explainable heuristic, not a probability)'), h('div', { class: 'score' }, i.score.total + '/100'), h('div', { class: 'mu' }, 'Evidence confidence: ' + i.score.confidence + ' | Business impact: ' + i.score.impact), i.score.parts.map(p => h('div', { class: 'mu' }, p.name + ': ' + p.pts + '/' + p.max + ' (' + p.why + ')')), h('h3', {}, 'Correlation'), h('div', {}, i.explanation),
          h('h3', {}, 'MITRE ATT&CK (demo mapping)'), i.alerts.map(a => { const m = CS.mitre[a.ruleId]; return h('div', {}, h('b', {}, a.ruleId + ': '), m.tech ? m.tactic + ', ' + m.tech + '. ' : '', m.why); }), h('div', { class: 'mu' }, CS.mitreSource)),
        h('div', { class: 'card' }, h('h3', {}, 'Assistant summary (local rules, not a live AI)'), h('p', {}, x.summary), h('h3', {}, 'Observed facts'), h('ul', {}, x.facts.map(f => h('li', {}, f.t + ' ', h('span', { class: 'mu' }, '[' + f.ids.join(', ') + ']')))), h('h3', {}, 'Possible explanations (unconfirmed)'), h('ul', {}, x.poss.map(p => h('li', {}, p))),
          h('h3', {}, 'Missing evidence'), h('ul', {}, x.miss.map(p => h('li', {}, p))), h('h3', {}, 'Suggested investigation steps'), h('ul', {}, x.steps.map(p => h('li', {}, p))), h('h3', {}, 'Containment options for human review'), h('ul', {}, x.containment.map(p => h('li', {}, p))))),
      h('div', { class: 'card' }, h('h3', {}, 'Event timeline (event text is untrusted data, shown as plain text)'), h('div', { class: 'tl' }, evs.map(e => h('div', {}, h('b', {}, fmt(e.ts) + ' ' + e.id + ' '), e.category + ' | ' + e.desc + ' | user ' + (e.user || 'n/a') + ' | src ' + (e.src || 'n/a') + ' | ' + e.source, h('div', { class: 'mu' }, JSON.stringify(e.evidence)))))),
      h('div', { class: 'card' }, h('h3', {}, 'Notes'), i.st.notes.map(n => h('div', {}, h('span', { class: 'mu' }, n.ts + ' '), n.text)), h('div', { class: 'row' }, note, btn('Add note', () => { CS.addNote(i.id, note.value) ? toast('Note saved') : toast('Enter a note first'); render(); }))));
  },
  endpoints() { return h('div', {}, h('div', { class: 'warn' }, 'All endpoints are simulated. This app does not inspect real devices.'), table([['ID', e => e.id], ['Hostname', e => e.host], ['OS', e => e.os], ['Last seen (demo)', e => e.seen], ['Importance (configured)', e => e.imp + '/3'], ['Incidents', e => CS.state.incidents.filter(i => i.endpoint === e.host).map(i => i.id).join(', ') || 'None'], ['Status', e => e.status]], CS.endpoints)); },
  intel() { return h('div', {}, h('div', { class: 'warn' }, 'Fictitious indicators using reserved documentation addresses. No external threat-intelligence service is queried. Integration point: CS.integrations.intel (disabled).'), table([['Indicator', r => r.ind], ['Type', r => r.type], ['Risk label', r => r.risk], ['Source', () => 'Local demo list'], ['Explanation', r => r.why], ['Related incidents', r => CS.state.incidents.filter(i => i.eventIds.some(id => (CS.state.events.find(e => e.id === id) || {}).src === r.ind)).map(i => i.id).join(', ') || 'None']], CS.intel)); },
  response() { const s = CS.state; if (!sel || !CS.inc(sel)) sel = s.incidents[0] && s.incidents[0].id; const i = CS.inc(sel);
    if (!i) return h('div', { class: 'empty' }, 'No incidents to respond to.');
    return h('div', {}, h('div', { class: 'warn' }, 'Simulation only. Approving an action records a decision. No command runs, no firewall, account, process or device is changed.'),
      h('label', {}, 'Incident ', h('select', { onchange: e => { sel = e.target.value; render(); } }, s.incidents.map(n => h('option', { value: n.id, ...(n.id === sel ? { selected: '' } : {}) }, n.id + ' ' + n.title)))),
      h('div', { class: 'grid g2' }, Object.entries(CS.actions).map(([k, a]) => h('div', { class: 'card' }, h('b', {}, a.label), h('p', { class: 'mu' }, 'Impact: ' + a.impact), h('button', { onclick: async () => { const ok = await ask('Approve: ' + a.label + '?', a.impact + ' This is a SIMULATION.', 'Approve'); CS.respond(i.id, k, ok); if (ok && k === 'report') { download(i.id + '.md', CS.report(CS.inc(i.id), 'md'), 'text/markdown'); CS.log('Report exported', i.id, 'Markdown'); } toast(ok ? 'Approved (simulated)' : 'Rejected'); render(); } }, 'Review action')))),
      h('h2', {}, 'Response history for ' + i.id), table([['Time', r => r.ts], ['Action', r => r.action], ['Decision', r => r.decision], ['Mode', () => 'Simulated']], i.st.responses));
  },
  audit() { return h('div', {}, h('div', { class: 'warn' }, 'Browser-local audit history can be edited or cleared by anyone with access to this browser. It is not tamper-proof enterprise logging.'), table([['ID', a => a.id], ['Time', a => a.ts], ['Action', a => a.action], ['Incident', a => a.inc || 'n/a'], ['Outcome', a => a.outcome], ['Mode', a => a.mode]], [...CS.state.audit].reverse())); },
  reports() { const s = CS.state, sl = h('select', { 'aria-label': 'Incident' }, s.incidents.map(i => h('option', { value: i.id }, i.id + ' ' + i.title)));
    const go1 = mode => { const i = CS.inc(sl.value); if (!i) return toast('No incident selected'); preview = CS.report(i, mode); download(i.id + (mode === 'json' ? '.json' : '.md'), preview, mode === 'json' ? 'application/json' : 'text/markdown'); CS.log('Report exported', i.id, mode.toUpperCase()); CS.save(); toast('Report exported'); render(); };
    return h('div', {}, s.incidents.length ? h('div', { class: 'row' }, sl, h('button', { class: 'pri', onclick: () => go1('md') }, 'Export Markdown'), h('button', { onclick: () => go1('json') }, 'Export JSON')) : h('div', { class: 'empty' }, 'No incidents to report.'), preview && h('pre', {}, preview)); },
  settings() { const s = CS.state, c = s.cfg, num = (k, l, mn) => h('label', {}, l + ' ', h('input', { type: 'number', min: mn, max: '999', value: c[k], style: 'width:80px', onchange: e => { const v = Math.floor(+e.target.value); if (v >= mn) { c[k] = v; CS.recompute(); CS.save(); toast('Rule updated and detection re-run'); } else e.target.value = c[k]; } }));
    const act = (l, f, msg, danger) => h('button', { onclick: async () => { if (danger && !await ask(l + '?', msg, 'Confirm')) return; f(); render(); toast(l + ' done'); } }, l);
    const out = h('div', {}); const file = h('input', { type: 'file', accept: '.json,application/json', 'aria-label': 'Import events JSON', onchange: async e => { try { const o = JSON.parse(await e.target.files[0].text()), v = CS.validateEvents(Array.isArray(o) ? o : o.events); if (!v.ok) return toast('Import rejected: ' + v.errors[0]); s.events = v.events; s.inc = {}; s.next = 1; CS.log('Events imported', null, v.events.length + ' events'); CS.recompute(); CS.save(); render(); toast('Imported ' + v.events.length + ' events'); } catch (er) { toast('Import rejected: not valid JSON'); } } });
    const run = () => { const r = CS.runTests(); out.replaceChildren(h('p', {}, r.filter(x => x.ok).length + ' of ' + r.length + ' passed (ran just now in this browser)'), ...r.map(x => h('div', { class: x.ok ? 'pass' : 'fail' }, (x.ok ? 'PASS ' : 'FAIL ') + x.n + (x.err ? ' ' + x.err : '')))); };
    return h('div', {}, h('div', { class: 'card' }, h('h2', {}, 'Detection rules (configurable)'), h('div', { class: 'row' }, num('failN', 'Failed logins to trigger', 2), num('failWin', 'Window (min)', 1), num('corrWin', 'Correlation window (min)', 1))),
      h('div', { class: 'card' }, h('h2', {}, 'Demo data'), h('div', { class: 'row' }, act('Generate sample incident', () => CS.gen('incident')), act('Generate related events', () => CS.gen('related')), act('Run detection again', () => { CS.recompute(); CS.log('Detection re-run', null, s.alerts.length + ' alerts'); CS.save(); }),
        act('Load original sample dataset', () => { const a = s.audit; CS.state = CS.fresh(); CS.state.audit = a; CS.log('Original dataset loaded', null, 'Fixtures restored'); CS.recompute(); CS.save(); }, 'Replaces events and incident states. Audit history is kept.', true),
        act('Reset demo data', () => { CS.state = CS.fresh(); CS.log('Demo data reset', null, 'All local state cleared'); CS.recompute(); CS.save(); sel = null; }, 'Clears all local incidents, notes, responses and audit history.', true)), h('div', { class: 'row' }, h('label', {}, 'Import events JSON ', file)),
        CS.saveFailed ? h('div', { class: 'warn' }, 'Browser storage is unavailable. Changes will be lost when you close this tab.') : h('div', { class: 'mu' }, 'State is saved in this browser only (localStorage). It is small, editable and not a production audit store.')),
      h('div', { class: 'card' }, h('h2', {}, 'Test panel'), h('button', { class: 'pri', onclick: run }, 'Run tests'), out, h('div', { class: 'mu' }, 'Tests run against a fresh copy of the fixtures and do not touch your current data.')));
  } };
const NAV = [['overview', 'Overview'], ['alerts', 'Security alerts'], ['incidents', 'Incident investigation'], ['endpoints', 'Endpoint inventory'], ['intel', 'Threat intelligence'], ['response', 'Response center'], ['audit', 'Audit history'], ['reports', 'Reports'], ['settings', 'Settings and tests']];
function go(p) { location.hash = p; render(); }
function render() { page = (location.hash || '#overview').slice(1); if (!PAGES[page]) page = 'overview'; $('#ptitle').textContent = NAV.find(n => n[0] === page)[1];
  $('#nav').replaceChildren(...NAV.map(([k, l]) => h('a', { href: '#' + k, ...(k === page ? { 'aria-current': 'page' } : {}) }, l)));
  try { $('#main').replaceChildren(PAGES[page]()); } catch (e) { $('#main').replaceChildren(h('div', { class: 'warn' }, 'This page failed to render: ' + e.message)); } }
addEventListener('hashchange', () => { render(); $('#main').focus(); });
CS.load(); CS.recompute(); CS.save(); render();
})();
